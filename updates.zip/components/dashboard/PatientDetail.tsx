import React, { useEffect, useMemo, useState } from 'react';
import { PatientFile, TestSession, Patient, ScoreResult, ReportMetadata } from '../../types';
import { ArrowLeft, Plus, TrendingUp, ChevronRight, Zap, LineChart as ChartIcon, FileText, Calendar, ChevronDown, ChevronUp, Lock, Unlock, AlertTriangle, Archive, Trash2, X, ArchiveRestore } from 'lucide-react';
import { CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart, XAxis, YAxis } from 'recharts';
import { CategoryDef } from '../../data/testCatalog';
import { SubtestRowCheck } from '../assessment/Step2Tests';
import { StorageService } from '../../services/storage';
import { useAuth } from '../../contexts/AuthContext';
import { useCatalog } from '../../contexts/CatalogContext';
import { useToast } from '../../contexts/ToastContext';

interface Props {
  file: PatientFile;
  onBack: () => void;
  onNewBilan: (type: 'initial' | 'reevaluation') => void;
  onQuickEntry: () => void;
  onOpenReport: (reportId: string) => void;
  draftAvailable?: boolean;
  onResumeDraft?: () => void;
}

// Fonction utilitaire pour retrouver la définition d'un sous-test n'importe où dans le catalogue
const findSubtestDefInCatalog = (subId: string, catalog: CategoryDef[]) => {
    for (const cat of catalog) {
        for (const test of cat.tests) {
            const sub = test.subtests.find(s => s.id === subId);
            if (sub) return { test, sub };
        }
    }
    return null;
};

const SessionRow: React.FC<{ session: TestSession; patient: Patient }> = ({ session, patient }) => {
    const { catalog } = useCatalog();
    const [isOpen, setIsOpen] = useState(false);
    
    const knownTestDef = catalog.flatMap(c => c.tests).find(t => t.id === session.testId);

    const itemsToRender = knownTestDef 
        ? knownTestDef.subtests.map(st => ({ 
            key: st.id, 
            def: { test: knownTestDef, sub: st }, 
            res: session.results[st.id] 
          }))
        : Object.entries(session.results).map(([subId, res]) => ({ 
            key: subId, 
            def: findSubtestDefInCatalog(subId, catalog), 
            res: res as ScoreResult 
          }));

    const validScores = (Object.values(session.results) as ScoreResult[]).filter(r => r.status === 'validated');
    const avgZ = validScores.reduce((acc, curr) => acc + curr.zScore, 0) / (validScores.length || 1);
    
    let statusColor = "text-stone-400";
    if(validScores.length > 0) {
        if (avgZ <= -2) statusColor = "text-[#E07A5F]";
        else if (avgZ <= -1) statusColor = "text-[#F2CC8F]";
        else statusColor = "text-[#81B29A]";
    }

    return (
        <div className={`border-b border-stone-100 transition-all duration-300 ${isOpen ? 'bg-white rounded-2xl shadow-lg border-transparent my-4' : 'hover:bg-stone-50'}`}>
            <div 
                onClick={() => setIsOpen(!isOpen)} 
                className="flex items-center justify-between p-5 cursor-pointer"
            >
                <div className="flex items-center gap-6">
                    <div className="flex flex-col items-center min-w-[60px]">
                        <span className="text-xs font-bold text-stone-400 uppercase">{new Date(session.date).toLocaleDateString('fr-FR', { month: 'short' })}</span>
                        <span className="text-xl font-serif font-bold text-[#3D405B]">{new Date(session.date).getDate()}</span>
                    </div>
                    <div className="h-8 w-px bg-stone-200"></div>
                    <div>
                        <h4 className="font-bold text-[#3D405B] text-lg">{session.testName}</h4>
                        <p className="text-xs text-stone-400 font-medium">{Object.keys(session.results).length} épreuves saisies</p>
                    </div>
                </div>
                
                <div className="flex items-center gap-6">
                    <div className={`flex items-center gap-2 font-bold text-sm ${statusColor}`}>
                        <div className={`w-2 h-2 rounded-full bg-current`}></div>
                        {validScores.length > 0 ? "Analysé" : "Brouillon"}
                    </div>
                    {isOpen ? <ChevronUp size={20} className="text-stone-300"/> : <ChevronDown size={20} className="text-stone-300"/>}
                </div>
            </div>

            {isOpen && (
                <div className="px-6 pb-6 pt-2 animate-in slide-in-from-top-2">
                    <div className="bg-stone-50 rounded-xl p-6 border border-stone-100">
                        <div className="flex items-center gap-2 mb-6 text-emerald-600 font-bold text-xs uppercase tracking-widest">
                            <Unlock size={14} /> Consultation Gratuite Illimitée
                        </div>
                        <div className="space-y-2">
                            {itemsToRender.map((item) => {
                                if (!item.res) return null; 

                                if (item.def) {
                                    return (
                                        <div key={item.key}>
                                            <SubtestRowCheck 
                                                testId={item.def.test.id}
                                                patient={patient}
                                                subtest={item.def.sub}
                                                result={item.res}
                                                onChange={() => {}}
                                                readOnly={true}
                                            />
                                        </div>
                                    );
                                } else {
                                    return (
                                        <div key={item.key} className="p-4 bg-white rounded-lg mb-2 text-sm text-stone-600 border border-stone-200 flex justify-between items-center">
                                            <div>
                                                <span className="font-bold uppercase text-xs text-stone-400 mr-2">{item.key}</span>
                                                <span className="font-mono font-bold text-[#3D405B]">Brut: {item.res.raw}</span>
                                            </div>
                                            <span className="text-xs text-stone-400 italic bg-stone-100 px-2 py-1 rounded">Test archivé (Définition manquante)</span>
                                        </div>
                                    );
                                }
                            })}
                            
                            {itemsToRender.length === 0 && (
                                <p className="text-stone-400 italic text-sm text-center py-4">Aucune donnée affichable.</p>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const ReportRow: React.FC<{ report: ReportMetadata; onOpen: (id: string) => void }> = ({ report, onOpen }) => {
    const label = report.type === 'initial' ? 'Bilan initial' : 'Réévaluation';

    return (
        <div
            onClick={() => onOpen(report.id)}
            className="border-b border-stone-100 hover:bg-stone-50 transition-all duration-300 cursor-pointer"
        >
            <div className="flex items-center justify-between p-5">
                <div className="flex items-center gap-6">
                    <div className="flex flex-col items-center min-w-[60px]">
                        <span className="text-xs font-bold text-stone-400 uppercase">
                            {new Date(report.date).toLocaleDateString('fr-FR', { month: 'short' })}
                        </span>
                        <span className="text-xl font-serif font-bold text-[#3D405B]">{new Date(report.date).getDate()}</span>
                    </div>
                    <div className="h-8 w-px bg-stone-200"></div>
                    <div>
                        <h4 className="font-bold text-[#3D405B] text-lg">{label}</h4>
                        <p className="text-xs text-stone-400 font-medium">
                            {report.sections?.length || 0} section{(report.sections?.length || 0) > 1 ? 's' : ''} - {new Date(report.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-[#E07A5F] bg-[#E07A5F]/10 px-2 py-1 rounded-full">
                        Document
                    </div>
                    <ChevronRight size={16} className="text-stone-300" />
                </div>
            </div>
        </div>
    );
};

const DeleteConfirmationModal: React.FC<{
    onConfirm: () => void;
    onCancel: () => void;
}> = ({ onConfirm, onCancel }) => {
    const [input, setInput] = useState('');
    const isValid = input.toLowerCase() === 'supprimer';

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-[#3D405B]/80 backdrop-blur-md animate-in fade-in duration-200">
            <div className="bg-white rounded-[32px] p-8 max-w-md w-full shadow-2xl text-center relative overflow-hidden">
                <button onClick={onCancel} className="absolute top-6 right-6 text-stone-300 hover:text-stone-500"><X size={24}/></button>
                
                <div className="w-20 h-20 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-6 text-rose-500">
                    <Trash2 size={32} />
                </div>
                
                <h3 className="font-serif font-bold text-2xl text-[#3D405B] mb-2">Zone de Danger</h3>
                <p className="text-stone-500 text-sm mb-6 leading-relaxed">
                    Cette action est <strong>irréversible</strong>. <br/>
                    Toutes les données, rapports et historiques de ce patient seront effacés définitivement.
                </p>

                <div className="mb-6">
                    <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2 block">
                        Tapez "supprimer" pour confirmer
                    </label>
                    <input 
                        type="text" 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        className="w-full text-center p-4 rounded-xl border-2 border-stone-200 focus:border-rose-500 outline-none font-bold text-rose-500 uppercase placeholder:normal-case placeholder:font-normal"
                        placeholder="supprimer"
                    />
                </div>

                <div className="flex gap-3">
                    <button onClick={onCancel} className="flex-1 py-3 text-stone-400 font-bold hover:bg-stone-50 rounded-xl transition-colors">Annuler</button>
                    <button 
                        onClick={onConfirm}
                        disabled={!isValid}
                        className={`flex-1 py-3 rounded-xl font-bold text-white shadow-lg transition-all ${isValid ? 'bg-rose-500 hover:bg-rose-600 hover:-translate-y-1' : 'bg-stone-300 cursor-not-allowed'}`}
                    >
                        Supprimer
                    </button>
                </div>
            </div>
        </div>
    );
};

export const PatientDetail: React.FC<Props> = ({ file, onBack, onNewBilan, onQuickEntry, onOpenReport, draftAvailable, onResumeDraft }) => {
    const { ensureCatalogLoaded } = useCatalog();
    useEffect(() => {
        ensureCatalogLoaded();
    }, [ensureCatalogLoaded]);
  const { orgKey } = useAuth(); // utilise orgKey pour gérer le dossier
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const toast = useToast();

  const chartData = useMemo(() => {
      if (!file.sessions || file.sessions.length === 0) return [];
      return file.sessions.map(s => {
          const scores = Object.values(s.results) as ScoreResult[];
          const validated = scores.filter(r => r.status === 'validated');
          const avgNote = validated.length > 0
              ? validated.reduce((sum, r) => sum + (r.standardScore ?? r.raw ?? 0), 0) / validated.length
              : null;
          return {
              date: new Date(s.date).toLocaleDateString('fr-FR', { month: 'short', day: 'numeric' }),
              score: avgNote !== null ? Math.round(avgNote * 10) / 10 : null,
              label: s.testName
          };
      }).filter(d => d.score !== null);
  }, [file.sessions]);

  const timelineItems = useMemo(() => {
      const sessions = (file.sessions || []).map(session => ({
          id: `session-${session.id}`,
          type: 'session' as const,
          date: session.date,
          session
      }));
      const reports = (file.reports || []).map(report => ({
          id: `report-${report.id}`,
          type: 'report' as const,
          date: report.date,
          report
      }));
      return [...sessions, ...reports].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [file.sessions, file.reports]);

  const [timelineFilter, setTimelineFilter] = useState<'all' | 'sessions' | 'reports'>('all');

  const filteredTimeline = useMemo(() => {
      if (timelineFilter === 'sessions') return timelineItems.filter(item => item.type === 'session');
      if (timelineFilter === 'reports') return timelineItems.filter(item => item.type === 'report');
      return timelineItems;
  }, [timelineItems, timelineFilter]);

  const reportStats = useMemo(() => {
      const reports = file.reports || [];
      const initialReports = reports.filter(r => r.type === 'initial');
      const reevaluations = reports.filter(r => r.type === 'reevaluation');
      const lastReport = reports.slice().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

      const addMonths = (iso: string, months: number) => {
          const d = new Date(iso);
          const day = d.getDate();
          d.setMonth(d.getMonth() + months);
          if (d.getDate() !== day) {
              d.setDate(0);
          }
          return d;
      };

      const nextWindow = lastReport
          ? { from: addMonths(lastReport.date, 6), to: addMonths(lastReport.date, 12) }
          : null;

      return {
          initialCount: initialReports.length,
          reevaluationCount: reevaluations.length,
          lastReport,
          nextWindow,
          isOverdue: nextWindow ? new Date() > nextWindow.to : false
      };
  }, [file.reports]);

  const handleArchive = async () => {
      if (!orgKey) return;
      setIsProcessing(true);
      try {
          await StorageService.toggleArchive(file, orgKey);
          onBack(); // Retour au dashboard pour rafraichir
          // Suppression du toast "Dossier mis à jour"
      } catch (e) {
          toast.error("Erreur lors de l'archivage.");
      } finally {
          setIsProcessing(false);
      }
  };

  const handleDelete = async () => {
      if (!orgKey) return;
      setIsProcessing(true);
      try {
          await StorageService.deleteFile(file.id);
          onBack(); 
          // Suppression du toast "Dossier supprimé"
      } catch (e) {
          toast.error("Erreur lors de la suppression.");
      } finally {
          setIsProcessing(false);
      }
  };

  // Handler Reeval
  const handleReeval = () => {
      onNewBilan('reevaluation');
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 animate-in slide-in-from-right duration-500">
      
      {/* Navigation */}
      <button onClick={onBack} className="flex items-center gap-2 text-stone-400 hover:text-[#3D405B] font-bold text-[10px] uppercase tracking-widest mb-8 transition-colors">
        <ArrowLeft size={16} /> Retour Dashboard
      </button>

      {/* ALERTE BROUILLON DISPONIBLE */}
      {draftAvailable && (
          <div className="mb-8 p-4 bg-amber-50 border-l-4 border-amber-400 rounded-r-xl shadow-sm flex items-center justify-between animate-in slide-in-from-top-2">
              <div className="flex items-center gap-3">
                  <div className="p-2 bg-white rounded-full text-amber-500 shadow-sm">
                      <AlertTriangle size={20} />
                  </div>
                  <div>
                      <h3 className="font-bold text-amber-900 text-sm">Brouillon de bilan non terminé</h3>
                      <p className="text-xs text-amber-700">Vous avez un travail en cours pour ce patient.</p>
                  </div>
              </div>
              <button 
                  onClick={onResumeDraft}
                  className="px-6 py-2 bg-amber-500 text-white rounded-lg font-bold text-xs uppercase tracking-wider hover:bg-amber-600 transition-colors shadow-md"
              >
                  Reprendre
              </button>
          </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div className="flex items-center gap-6">
            <div className={`w-20 h-20 rounded-2xl flex items-center justify-center font-serif font-bold text-3xl shadow-xl shadow-[#3D405B]/10 transform -rotate-3 ${file.archived ? 'bg-stone-300 text-white' : 'bg-[#3D405B] text-white'}`}>
                {file.patient.firstName.charAt(0)}{file.patient.lastName.charAt(0)}
            </div>
            <div>
                <h1 className="font-serif text-4xl font-bold text-[#3D405B] mb-1 flex items-center gap-3">
                    {file.patient.firstName} {file.patient.lastName}
                    {file.archived && <span className="bg-stone-100 text-stone-400 text-xs px-3 py-1 rounded-full uppercase tracking-wider border border-stone-200">Archivé</span>}
                </h1>
                <div className="flex gap-2">
                    <span className="text-[10px] font-bold uppercase bg-stone-100 px-2 py-1 rounded text-stone-500">{file.patient.age}</span>
                    <span className="text-[10px] font-bold uppercase bg-[#E07A5F]/10 px-2 py-1 rounded text-[#E07A5F]">{file.patient.classLevel}</span>
                </div>
            </div>
        </div>
        
        <div className="flex gap-3">
             <button onClick={onQuickEntry} className="flex items-center gap-2 bg-white text-[#3D405B] px-6 py-4 rounded-2xl font-bold shadow-sm border border-stone-200 hover:bg-stone-50 hover:border-[#E07A5F] transition-all text-sm group">
                <Plus size={18} className="text-[#E07A5F]" /> 
                <span className="group-hover:text-[#E07A5F]">Saisie Rapide</span>
            </button>
            <button 
                onClick={handleReeval}
                className="flex items-center gap-2 bg-[#3D405B] text-white px-8 py-4 rounded-2xl font-bold shadow-xl shadow-stone-300 hover:bg-[#2c2e42] transition-all hover:-translate-y-1 text-sm group relative overflow-hidden"
            >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <Zap size={18} className="text-[#F2CC8F]" /> 
                Générer Bilan PDF
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* COLONNE GAUCHE (VISUALISATION & HISTORIQUE) */}
        <div className="lg:col-span-2 space-y-12">
            
            {/* 1. GRAPHIQUE */}
            <div className="bg-white rounded-[32px] p-8 border border-stone-100 shadow-sm relative overflow-hidden">
                <div className="flex justify-between items-start mb-8">
                    <div>
                        <h2 className="font-serif text-xl font-bold text-[#3D405B] flex items-center gap-2">
                            <ChartIcon size={24} className="text-[#E07A5F]" /> Courbe d'Évolution
                        </h2>
                        <p className="text-xs text-stone-400 font-medium mt-1">Données agrégées de toutes les sessions.</p>
                    </div>
                    <div className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-bold flex items-center gap-1">
                        <TrendingUp size={12}/> Tendance positive
                    </div>
                </div>

                <div className="h-[280px] w-full">
                     {chartData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={chartData}>
                                <defs>
                                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#E07A5F" stopOpacity={0.1}/>
                                        <stop offset="95%" stopColor="#E07A5F" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f5" />
                                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700, fill: '#A8A29E'}} />
                                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700, fill: '#A8A29E'}} domain={[0, 20]} />
                                <Tooltip 
                                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', padding: '12px' }}
                                    labelStyle={{ fontWeight: 800, color: '#3D405B', marginBottom: '4px' }}
                                />
                                <Area 
                                    type="monotone" 
                                    dataKey="score" 
                                    stroke="#E07A5F" 
                                    strokeWidth={4} 
                                    fillOpacity={1} 
                                    fill="url(#colorScore)" 
                                    animationDuration={1500}
                                    dot={{ r: 6, fill: '#E07A5F', strokeWidth: 3, stroke: '#fff' }}
                                    activeDot={{ r: 8, strokeWidth: 0 }}
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                     ) : (
                         <div className="h-full flex flex-col items-center justify-center text-stone-300">
                             <TrendingUp size={48} className="mb-4 opacity-50"/>
                             <p>Aucune donnée. Saisissez une première séance.</p>
                         </div>
                     )}
                </div>
            </div>

            {/* 2. TIMELINE UNIFIÉE (SÉANCES + BILANS) */}
            <div>
                <div className="flex flex-col gap-3 mb-6 px-2">
                    <div className="flex items-center gap-3">
                        <Calendar size={24} className="text-[#3D405B]" />
                        <h2 className="font-serif text-2xl font-bold text-[#3D405B]">Historique global</h2>
                        <div className="ml-auto flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-stone-400 bg-stone-100 px-3 py-1 rounded-full">
                            <Unlock size={12} /> Accès Libre
                        </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-stone-400">
                        <span className="bg-stone-100 px-3 py-1 rounded-full">1 bilan initial</span>
                        <span className="bg-stone-100 px-3 py-1 rounded-full">Réévaluation 6-12 mois</span>
                        {reportStats.initialCount === 0 && (
                            <span className="bg-amber-50 text-amber-700 px-3 py-1 rounded-full">Bilan initial manquant</span>
                        )}
                        {reportStats.initialCount > 1 && (
                            <span className="bg-rose-50 text-rose-600 px-3 py-1 rounded-full">{reportStats.initialCount} bilans initiaux</span>
                        )}
                        {reportStats.nextWindow && (
                            <span className="bg-[#E07A5F]/10 text-[#E07A5F] px-3 py-1 rounded-full">
                                Fenêtre recommandée: {reportStats.nextWindow.from.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })} - {reportStats.nextWindow.to.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                            </span>
                        )}
                        {reportStats.isOverdue && (
                            <span className="bg-rose-50 text-rose-600 px-3 py-1 rounded-full">Réévaluation en retard</span>
                        )}
                    </div>
                    <div className="flex items-center gap-2">
                        {([
                            { id: 'all', label: 'Tout' },
                            { id: 'sessions', label: 'Séances' },
                            { id: 'reports', label: 'Bilans' }
                        ] as const).map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setTimelineFilter(tab.id)}
                                className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border transition-all ${
                                    timelineFilter === tab.id
                                        ? 'bg-[#3D405B] text-white border-[#3D405B]'
                                        : 'bg-white text-stone-400 border-stone-200 hover:text-stone-600'
                                }`}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="bg-white rounded-[32px] border border-stone-200 shadow-sm overflow-hidden relative">
                    <div className="absolute top-0 bottom-0 left-[85px] w-px bg-stone-100 z-0"></div>

                    {filteredTimeline.length === 0 ? (
                        <div className="p-12 text-center">
                            <p className="text-stone-400 font-medium">
                                {timelineFilter === 'reports' ? 'Aucun bilan disponible.' : timelineFilter === 'sessions' ? 'Aucune séance saisie.' : "L'historique est vide."}
                            </p>
                            {(timelineFilter === 'sessions' || timelineFilter === 'all') && (
                                <button onClick={onQuickEntry} className="mt-4 text-[#E07A5F] font-bold text-sm hover:underline">Ajouter une séance maintenant</button>
                            )}
                        </div>
                    ) : (
                        <div className="relative z-10">
                            {filteredTimeline.map(item => (
                                item.type === 'session'
                                    ? <SessionRow key={item.id} session={item.session} patient={file.patient} />
                                    : <ReportRow key={item.id} report={item.report} onOpen={onOpenReport} />
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>

        {/* COLONNE DROITE */}
        <div className="space-y-6">
            <div className="space-y-4">
                <h3 className="font-serif font-bold text-lg text-[#3D405B] px-2 flex items-center gap-2">
                    <Lock size={18} className="text-[#E07A5F]" /> 
                    Documents Formels
                </h3>
                {file.reports.map((report) => (
                    <div key={report.id} onClick={() => onOpenReport(report.id)} className="bg-white p-5 rounded-2xl border border-stone-100 hover:border-[#E07A5F] hover:shadow-lg hover:shadow-orange-100/50 transition-all cursor-pointer flex justify-between items-center group">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-rose-50 rounded-xl text-rose-500 group-hover:bg-[#E07A5F] group-hover:text-white transition-colors">
                                <FileText size={20} />
                            </div>
                            <div>
                                <h4 className="font-bold text-sm text-[#3D405B]">{report.type === 'initial' ? 'Bilan Initial' : 'Réévaluation'}</h4>
                                <p className="text-[10px] font-bold text-stone-400">{new Date(report.date).toLocaleDateString('fr-FR', {day: '2-digit', month: 'long', year: 'numeric'})}</p>
                            </div>
                        </div>
                        <ChevronRight size={16} className="text-stone-300 group-hover:translate-x-1 transition-all" />
                    </div>
                ))}
            </div>

            <div className="bg-white border border-stone-100 p-6 rounded-[24px] mt-8">
                 <h4 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-4">Fiche Administrative</h4>
                 <div className="space-y-4 text-sm">
                     <div>
                        <p className="text-[10px] font-bold text-stone-300 uppercase">Parent Référent</p>
                        <p className="font-bold text-[#3D405B]">{file.patient.parentNames}</p>
                     </div>
                     <div>
                        <p className="text-[10px] font-bold text-stone-300 uppercase">Téléphone</p>
                        <p className="font-bold text-[#3D405B]">{file.patient.parentPhone}</p>
                     </div>
                     <div>
                         <p className="text-[10px] font-bold text-stone-300 uppercase">Email</p>
                         <p className="font-bold text-[#3D405B] truncate">{file.patient.parentEmail}</p>
                     </div>
                 </div>
            </div>

            {/* ZONE D'ACTIONS DOSSIER */}
            <div className="pt-4 space-y-3">
                <button 
                    onClick={handleArchive}
                    disabled={isProcessing}
                    className="w-full py-3 bg-stone-100 text-stone-500 hover:bg-stone-200 hover:text-stone-700 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
                >
                    {file.archived ? <ArchiveRestore size={16} /> : <Archive size={16} />}
                    {file.archived ? "Désarchiver le dossier" : "Archiver le dossier"}
                </button>
                <button 
                    onClick={() => setShowDeleteModal(true)}
                    className="w-full py-3 bg-white border border-rose-100 text-rose-400 hover:bg-rose-50 hover:text-rose-600 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
                >
                    <Trash2 size={16} /> Supprimer le dossier
                </button>
            </div>
        </div>
      </div>

      {showDeleteModal && (
          <DeleteConfirmationModal 
            onConfirm={handleDelete}
            onCancel={() => setShowDeleteModal(false)}
          />
      )}
    </div>
  );
};
